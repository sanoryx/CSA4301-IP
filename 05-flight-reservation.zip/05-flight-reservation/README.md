# 5. Flight Reservation System

Search flights, seat map, booking, payment page, my tickets, cancel, print ticket, feedback, forgot password. Admin: flights/fares, booking status, feedback, report.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
Admin: admin@fly.com / admin123 | User: user@fly.com / 1234

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Passwords are plain text and payments/email/SMS are simulated (demo only).
- Files: `index.html`, `style.css`, `common.js` (shared helpers), `app.js` (this program).
