/* Shared helpers: storage, auth (demo, localStorage), layout */
const NS=document.body.dataset.ns||'app_';
const DB={get(k,d){try{const v=JSON.parse(localStorage.getItem(NS+k));return v==null?d:v}catch(e){return d}},set(k,v){localStorage.setItem(NS+k,JSON.stringify(v))},del(k){localStorage.removeItem(NS+k)}};
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ymd=d=>new Date(d.getTime()-d.getTimezoneOffset()*6e4).toISOString().slice(0,10);
const today=()=>ymd(new Date());
const addDays=(s,n)=>{const x=new Date(s+'T00:00:00');x.setDate(x.getDate()+n);return ymd(x)};
const diffDays=(a,b)=>Math.round((new Date(b+'T00:00:00')-new Date(a+'T00:00:00'))/864e5);
const fd=e=>{e.preventDefault();return Object.fromEntries(new FormData(e.target))};
const opt=(a,all)=>(all!=null?`<option value="">${all}</option>`:'')+a.map(x=>`<option>${esc(x)}</option>`).join('');
const tbl=(h,r)=>`<div class="tblwrap"><table><tr>${h.map(x=>`<th>${x}</th>`).join('')}</tr>${r.length?r.map(c=>`<tr>${c.map(x=>`<td>${x}</td>`).join('')}</tr>`).join(''):`<tr><td colspan="${h.length}">No records yet</td></tr>`}</table></div>`;
const rs=n=>'₹'+Number(n).toLocaleString('en-IN',{maximumFractionDigits:2});
function toast(m){const t=document.createElement('div');t.className='toast';t.textContent=m;document.body.append(t);setTimeout(()=>t.remove(),2300)}
function download(name,text){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type:'text/plain'}));a.download=name;a.click()}
const Auth={
 users:()=>DB.get('users',[]),
 seed(l){if(!DB.get('seeded')){DB.set('users',l);DB.set('seeded',1)}},
 me(){const e=DB.get('session');return Auth.users().find(u=>u.email===e)||null},
 save(u){DB.set('users',Auth.users().map(x=>x.email===u.email?u:x))},
 logout(){DB.del('session');location.reload()}
};
function mountAuth(el,o,cb){o=o||{};const rr=o.regRoles||['user'];
 el.innerHTML=`<div class="card auth"><h2 id="at">${o.title||'Login'}</h2><form id="af"><div class="rg hide"><label>Full name</label><input name="name">${rr.length>1?`<label>Register as</label><select name="role">${opt(rr)}</select>`:`<input type="hidden" name="role" value="${rr[0]}">`}${o.extra||''}</div><label>Email</label><input name="email" type="email" required><label>Password</label><input name="password" type="password" required minlength="4"><button class="btn" style="width:100%">Login</button></form>${o.noReg?'':'<p><a href="#" id="sw">New here? Register</a></p>'}<small>${o.hint||''}</small></div>`;
 let reg=false;const sw=$('#sw',el);
 if(sw)sw.onclick=e=>{e.preventDefault();reg=!reg;$('.rg',el).classList.toggle('hide',!reg);$('#at',el).textContent=reg?'Register':(o.title||'Login');$('#af button',el).textContent=reg?'Register':'Login';sw.textContent=reg?'Have an account? Login':'New here? Register'};
 $('#af',el).onsubmit=e=>{const f=fd(e),us=Auth.users();
  if(reg){if(!f.name)return toast('Enter your name');if(us.some(u=>u.email===f.email))return toast('Email already registered');us.push(f);DB.set('users',us)}
  else if(!us.some(u=>u.email===f.email&&u.password===f.password))return toast('Invalid email or password');
  DB.set('session',f.email);cb()}}
let CUR,TABS;
function refresh(){TABS[CUR]($('#mn'))}
function shell(title,tabs,me){TABS=tabs;
 document.body.innerHTML=`<header><h1>${title}</h1><nav id="nv"></nav><span>${esc(me.name)} <small>(${esc(me.role)})</small> <button class="btn sm sec" style="color:inherit;border-color:currentColor" id="lo">Logout</button></span></header><main id="mn"></main>`;
 $('#lo').onclick=Auth.logout;
 Object.keys(tabs).forEach(n=>{const b=document.createElement('button');b.textContent=n;b.onclick=()=>{CUR=n;$$('#nv button').forEach(x=>x.classList.toggle('on',x===b));refresh()};$('#nv').append(b)});
 $('#nv button').click()}
function forgot(el){$('.auth',el).insertAdjacentHTML('beforeend','<p><a href="#" id="fp">Forgot password?</a></p>');$('#fp',el).onclick=e=>{e.preventDefault();const em=prompt('Registered email'),u=Auth.users().find(x=>x.email===em);if(!u)return toast('Email not found');const p=prompt('Enter new password (min 4 characters)');if(p&&p.length>=4){u.password=p;Auth.save(u);toast('Password reset. Please login.')}}}
function pwView(m){m.innerHTML=`<div class="card"><h3>Change password</h3><form id="pf"><label>Current password</label><input type="password" name="o" required><label>New password</label><input type="password" name="n" minlength="4" required><button class="btn">Update password</button></form></div>`;$('#pf').onsubmit=e=>{const f=fd(e),u=Auth.me();if(u.password!==f.o)return toast('Current password is wrong');u.password=f.n;Auth.save(u);toast('Password changed');e.target.reset()}}
const seatGrid=(labels,taken)=>`<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(52px,1fr));gap:6px;max-width:360px">${labels.map(l=>`<button type="button" class="btn sm ${taken.includes(l)?'red':'sec'}" ${taken.includes(l)?'disabled':''} onclick="seat(this,'${l}')">${l}</button>`).join('')}</div><small>Red = already booked</small>`;
