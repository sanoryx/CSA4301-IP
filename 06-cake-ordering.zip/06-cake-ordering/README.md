# 6. Online Cake Ordering

Search/filter cakes (category, sub category, price), cart, shipping address, orders and shipping status. Admin: post cakes with image upload, manage orders.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
Admin: admin@cake.com / admin123 | Customer: cust@cake.com / 1234

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Passwords are plain text and payments/email/SMS are simulated (demo only).
- Files: `index.html`, `style.css`, `common.js` (shared helpers), `app.js` (this program).
