# 7. Beauty Parlour Appointment Booking

Reservation calendar, slot lockout, full/deposit/pay-later payments with auto-cancel of unpaid bookings, account page, manager tools (add/edit/cancel, call/SMS, feedback).

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
Manager: manager@salon.com / admin123 | Customer: cust@salon.com / 1234

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Passwords are plain text and payments/email/SMS are simulated (demo only).
- Files: `index.html`, `style.css`, `common.js` (shared helpers), `app.js` (this program).
