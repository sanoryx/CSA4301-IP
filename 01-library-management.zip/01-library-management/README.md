# 1. Library Management System

Admin: login, add/update/delete book, issue, return, fine, year/semester material. User: register, search, borrow history (issue/expiry date), fine, material search/download, profile.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
Librarian: admin@lib.com / admin123 | Student: student@lib.com / 1234

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Passwords are plain text and payments/email/SMS are simulated (demo only).
- Files: `index.html`, `style.css`, `common.js` (shared helpers), `app.js` (this program).
