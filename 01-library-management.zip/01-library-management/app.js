Auth.seed([{name:'Librarian',email:'admin@lib.com',password:'admin123',role:'admin'},{name:'Demo Student',email:'student@lib.com',password:'1234',role:'student',year:'2',dept:'CSE'}]);
if(!DB.get('books')){
 DB.set('books',[{id:'b1',title:'Operating System Concepts',author:'Silberschatz',isbn:'9781118063330',copies:3},{id:'b2',title:'Computer Networks',author:'Tanenbaum',isbn:'9780132126953',copies:2},{id:'b3',title:'Database System Concepts',author:'Korth',isbn:'9780078022159',copies:2}]);
 DB.set('issues',[]);DB.set('mats',[{id:'m1',title:'DBMS Unit 1 Notes',year:'2',sem:'3',content:'Sample DBMS notes: ER model, keys, normalization.'}]);
}
const FINE=5,DAYS=14,B=()=>DB.get('books',[]),I=()=>DB.get('issues',[]),M=()=>DB.get('mats',[]);
const fineOf=i=>i.paid?0:Math.max(0,diffDays(i.due,i.returned||today()))*FINE;
const avail=b=>b.copies-I().filter(i=>i.bid===b.id&&!i.returned).length;
const bt=id=>esc((B().find(b=>b.id===id)||{}).title||'(deleted)');

function start(){const me=Auth.me();
 if(!me)return mountAuth($('#app'),{regRoles:['student'],hint:'Demo: admin@lib.com / admin123 · student@lib.com / 1234',extra:'<label>Year</label><input name="year"><label>Department</label><input name="dept">'},start);
 shell('📚 City Library',me.role==='admin'?{Books:adminBooks,'Issue / Return':issueView,Fines:fineView,Materials:matView}:{'Search Books':searchView,'My Borrowings':myIssues,'My Fines':myFines,Materials:matView,Profile:profile},me)}

const bookTable=(q,adm)=>tbl(['Title','Author','ISBN','Available',adm?'Actions':''],B().filter(b=>(b.title+b.author+b.isbn).toLowerCase().includes(q.toLowerCase())).map(b=>[esc(b.title),esc(b.author),esc(b.isbn),avail(b)+' / '+b.copies,adm?`<button class="btn sm" onclick="editBook('${b.id}')">Update</button> <button class="btn sm red" onclick="delBook('${b.id}')">Delete</button>`:'']));
function searchBox(m,adm,pre=''){m.insertAdjacentHTML('beforeend',`<div class="card">${pre}<input id="q" placeholder="Search by title, author or ISBN"><div id="t"></div></div>`);const d=()=>$('#t').innerHTML=bookTable($('#q').value,adm);$('#q').oninput=d;d()}
function adminBooks(m){m.innerHTML=`<div class="card"><h3>Add Book</h3><form id="f" class="row"><input name="title" placeholder="Title" required><input name="author" placeholder="Author" required><input name="isbn" placeholder="ISBN"><input name="copies" type="number" min="1" value="1"><button class="btn">Add Book</button></form></div>`;
 $('#f').onsubmit=e=>{const f=fd(e),b=B();b.push({id:uid(),...f,copies:+f.copies});DB.set('books',b);toast('Book added');refresh()};searchBox(m,true)}
function editBook(id){const bs=B(),b=bs.find(x=>x.id===id),t=prompt('Title',b.title);if(t===null)return;b.title=t||b.title;b.author=prompt('Author',b.author)||b.author;b.copies=+prompt('Copies',b.copies)||b.copies;DB.set('books',bs);refresh()}
function delBook(id){if(confirm('Delete this book?')){DB.set('books',B().filter(b=>b.id!==id));refresh()}}
function searchView(m){m.innerHTML='';searchBox(m,false)}

function issueView(m){const st=Auth.users().filter(u=>u.role==='student');
 m.innerHTML=`<div class="card"><h3>Issue Book</h3><form id="f" class="row"><select name="bid">${B().filter(b=>avail(b)>0).map(b=>`<option value="${b.id}">${esc(b.title)}</option>`).join('')}</select><select name="sid">${st.map(u=>`<option value="${u.email}">${esc(u.name)} (${u.email})</option>`).join('')}</select><button class="btn">Issue for ${DAYS} days</button></form></div>
 <div class="card"><h3>Issue Register</h3>${tbl(['Book','Student','Issued','Expiry','Status','Fine',''],I().slice().reverse().map(i=>[bt(i.bid),i.sid,i.date,i.due,i.returned?'Returned '+i.returned:'<b>Issued</b>',fineOf(i)?rs(fineOf(i)):'-',i.returned?'':`<button class="btn sm" onclick="ret('${i.id}')">Mark returned</button>`]))}</div>`;
 $('#f').onsubmit=e=>{const f=fd(e);if(!f.bid||!f.sid)return toast('Choose a book and a student');const is=I();is.push({id:uid(),...f,date:today(),due:addDays(today(),DAYS),returned:null,paid:false});DB.set('issues',is);toast('Book issued');refresh()}}
function ret(id){const is=I(),i=is.find(x=>x.id===id);i.returned=today();DB.set('issues',is);toast(fineOf(i)?'Returned late. Fine '+rs(fineOf(i)):'Returned');refresh()}
function fineView(m){const l=I().filter(i=>fineOf(i)>0);m.innerHTML=`<div class="card"><h3>Fines (₹${FINE}/day after expiry)</h3>${tbl(['Student','Book','Expiry','Returned','Fine',''],l.map(i=>[i.sid,bt(i.bid),i.due,i.returned||'Not yet',rs(fineOf(i)),`<button class="btn sm" onclick="payFine('${i.id}')">Mark paid</button>`]))}</div>`}
function payFine(id){const is=I(),i=is.find(x=>x.id===id);if(!i.returned)return toast('Book not returned yet');i.paid=true;DB.set('issues',is);refresh()}
function myIssues(m){const me=Auth.me();m.innerHTML=`<div class="card"><h3>My Borrow History</h3>${tbl(['Book','Issue date','Expiry date','Status'],I().filter(i=>i.sid===me.email).reverse().map(i=>[bt(i.bid),i.date,i.due,i.returned?'Returned '+i.returned:(i.due<today()?'<span class="bad">Overdue</span>':'Issued')]))}</div>`}
function myFines(m){const me=Auth.me(),l=I().filter(i=>i.sid===me.email&&fineOf(i)>0),t=l.reduce((s,i)=>s+fineOf(i),0);m.innerHTML=`<div class="card"><h3>My Fine</h3><p class="big ${t?'bad':'ok'}">${rs(t)}</p>${tbl(['Book','Expiry','Fine'],l.map(i=>[bt(i.bid),i.due,rs(fineOf(i))]))}<p><small>Pay the fine at the library counter; the librarian will mark it paid.</small></p></div>`}

function matView(m){const adm=Auth.me().role==='admin';
 m.innerHTML=(adm?`<div class="card"><h3>Update Material</h3><form id="f" class="row"><input name="title" placeholder="Title" required><select name="year">${opt([1,2,3,4])}</select><select name="sem">${opt([1,2,3,4,5,6,7,8])}</select><textarea name="content" placeholder="Notes / content"></textarea><button class="btn">Add</button></form></div>`:'')+`<div class="card"><h3>${adm?'View':'Search'} Material</h3><div class="row"><select id="y">${opt([1,2,3,4],'All years')}</select><select id="s">${opt([1,2,3,4,5,6,7,8],'All semesters')}</select></div><div id="t"></div></div>`;
 const d=()=>$('#t').innerHTML=tbl(['Title','Year','Sem',''],M().filter(x=>(!$('#y').value||x.year===$('#y').value)&&(!$('#s').value||x.sem===$('#s').value)).map(x=>[esc(x.title),x.year,x.sem,`<button class="btn sm" onclick="dlMat('${x.id}')">Download</button>${adm?` <button class="btn sm red" onclick="delMat('${x.id}')">Delete</button>`:''}`]));
 $('#y').onchange=$('#s').onchange=d;d();if(adm)$('#f').onsubmit=e=>{const ms=M();ms.push({id:uid(),...fd(e)});DB.set('mats',ms);toast('Material added');refresh()}}
function dlMat(id){const x=M().find(m=>m.id===id);download(x.title.replace(/\W+/g,'_')+'.txt',`${x.title}\nYear ${x.year} · Semester ${x.sem}\n\n${x.content}`)}
function delMat(id){DB.set('mats',M().filter(m=>m.id!==id));refresh()}
function profile(m){const u=Auth.me();m.innerHTML=`<div class="card"><h3>My Profile</h3><form id="f"><label>Name</label><input name="name" value="${esc(u.name)}"><label>Email</label><input value="${esc(u.email)}" disabled><label>Year</label><input name="year" value="${esc(u.year||'')}"><label>Department</label><input name="dept" value="${esc(u.dept||'')}"><button class="btn">Save profile</button></form></div>`;$('#f').onsubmit=e=>{Auth.save({...u,...fd(e)});toast('Profile saved');refresh()}}
start();
