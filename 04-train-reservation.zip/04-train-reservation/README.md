# 4. Railway Reservation System

Train search with seat availability, booking with PNR (Confirmed/RAC/WL), PNR status, cancellation with refund rules, print ticket. Admin: trains/fares, refund rules, payments, refund approval.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
Admin: admin@rail.com / admin123 | Passenger: pax@rail.com / 1234

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Passwords are plain text and payments/email/SMS are simulated (demo only).
- Files: `index.html`, `style.css`, `common.js` (shared helpers), `app.js` (this program).
