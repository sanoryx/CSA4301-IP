# 3. Online Bus Ticket Booking

Search by route/date/time, seat selection, passenger details, payment, cancel ticket, comments, change/forgot password. Admin: categories, buses, users, comments, reports.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
Admin: admin@bus.com / admin123 | User: user@bus.com / 1234

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Passwords are plain text and payments/email/SMS are simulated (demo only).
- Files: `index.html`, `style.css`, `common.js` (shared helpers), `app.js` (this program).
