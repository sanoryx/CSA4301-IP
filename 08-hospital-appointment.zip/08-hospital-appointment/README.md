# 8. Hospital Appointment Booking

Patient: search by location/specialty, hospital list with Google Map, booking with check-in form, status, reviews. Hospital: register, details, location, doctors, appointments, statistics.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
Patient: patient@hosp.com / 1234 | Hospital: city@hosp.com / 1234

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Passwords are plain text and payments/email/SMS are simulated (demo only).
- Files: `index.html`, `style.css`, `common.js` (shared helpers), `app.js` (this program).
