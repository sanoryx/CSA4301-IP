# 2. Hotel Room Booking

Register, availability check, booking, history, change/cancel up to 3 days before arrival. Admin: room quantity/price, edit/cancel any booking, edit static pages.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
Admin: admin@hotel.com / admin123 | Guest: guest@hotel.com / 1234

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Passwords are plain text and payments/email/SMS are simulated (demo only).
- Files: `index.html`, `style.css`, `common.js` (shared helpers), `app.js` (this program).
