# 9. TechSavvy Online Shop

Categories/sub-categories on home, search, availability, cart edit/remove, wishlist, reviews, checkout, order status/history, recommendations. Admin: add/remove items, price, description, customer orders.

## Run
Open `index.html` in a browser. No server or install needed.

## Demo logins
Admin: admin@tech.com / admin123 | Customer: cust@tech.com / 1234 | Promo: TECH10

## Notes
- Front-end only: data is saved in the browser (localStorage). Clear site data to reset.
- Passwords are plain text and payments/email/SMS are simulated (demo only).
- Files: `index.html`, `style.css`, `common.js` (shared helpers), `app.js` (this program).
